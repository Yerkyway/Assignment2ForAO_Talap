package test.assignment2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @PostMapping("/average")
    public String calculateAverage(@RequestParam("numbers") String numbers, Model model) {
        String[] numsArray = numbers.split(",");
        double sum = 0;
        for (String num : numsArray) {
            sum += Double.parseDouble(num);
        }
        double average = sum / numsArray.length;
        model.addAttribute("averageResult", "Average number: " + average);
        return "home";
    }

    @PostMapping("/palindrome")
    public String checkPalindrome(@RequestParam("word") String word, Model model) {
        String reversedWord = new StringBuilder(word).reverse().toString();
        boolean isPalindrome = word.equals(reversedWord);
        if (isPalindrome) {
            model.addAttribute("palindromeResult", word+" is palindrome");
        } else {
            model.addAttribute("palindromeResult", word+" is not palindrome");
        }
        return "home";
    }

    @PostMapping("/reverse")
    public String reverseNumber(@RequestParam("number") int number, Model model) {
        int reversedNumber = 0;
        while (number > 0) {
            int digit = number % 10;
            reversedNumber = reversedNumber * 10 + digit;
            number /= 10;
        }

        model.addAttribute("reverseResult", "Reverse: " + reversedNumber);
        return "home";
    }
}
