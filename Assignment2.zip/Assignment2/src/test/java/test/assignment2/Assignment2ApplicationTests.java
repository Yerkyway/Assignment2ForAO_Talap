package test.assignment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
